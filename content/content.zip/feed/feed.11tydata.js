module.exports = {
	eleventyExcludeFromCollections: true
}
