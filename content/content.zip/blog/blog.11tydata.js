module.exports = {
	tags: [
		"posts"
	],
	"layout": "layouts/post.njk",
};
